# Plugin for Inserting New Blocks Before and After Text

This plugin introduces a feature known as a floating button, which materializes at the boundary of images or tables.

The purpose of this button is to facilitate the insertion of new paragraphs either before or after the selected text, thereby optimizing the utilization of available space.
