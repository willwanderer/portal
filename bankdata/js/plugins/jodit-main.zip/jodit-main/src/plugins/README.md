# Plugins

This directory contains the plugins that are used by the application. The plugins are used to extend the functionality of the application.

Plugins are written in TypeScript and are compiled to JavaScript. The plugins can be loaded dynamically by the application.

[More about plugin system](https://xdsoft.net/jodit/docs/plugin-system.html)
