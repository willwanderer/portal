# Jodit Overview

This plugin introduces a button adorned with a question mark icon.
Upon clicking this button, a dialog box is displayed,
providing information about the Jodit version along with other pertinent details.
