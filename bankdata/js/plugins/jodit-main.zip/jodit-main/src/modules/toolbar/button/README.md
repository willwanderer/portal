# Toolbar button

## Description

This module provides a toolbar button for the application.
