# Toolbar collection list

## Description

This module provides a toolbar collection list for the application.
