# Toolbar

This module provides a toolbar for the application.
