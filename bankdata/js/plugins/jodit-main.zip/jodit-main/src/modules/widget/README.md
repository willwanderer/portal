# Jodit widgets

Jodit has a lot of widgets that can be used in the editor.
