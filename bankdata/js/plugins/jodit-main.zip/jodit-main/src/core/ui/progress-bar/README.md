# Progress Bar UI element
