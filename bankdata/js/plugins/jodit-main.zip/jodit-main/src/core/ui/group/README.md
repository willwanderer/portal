# Group component

Group component is a container for other components. It can be used to group buttons in the toolbar.
