Change `ACCESS_TOKEN` to your public MapBox access token: https://account.mapbox.com/access-tokens/

Run this using simple HTTP server https://gist.github.com/willurd/5720255

For example,

```bash
php -S 0.0.0.0:8000 -t .
```

or

```bash
python -m SimpleHTTPServer 8000
```

Then access it on http://localhost:8000
